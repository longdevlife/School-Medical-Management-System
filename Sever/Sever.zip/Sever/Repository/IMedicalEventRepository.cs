﻿using Microsoft.EntityFrameworkCore;
using Sever.Context;
using Sever.DTO.MedicalEvent;
using Sever.Model;

namespace Sever.Repository.Interfaces
{
    public interface IMedicalEventRepository
    {
        Task<MedicalEvent> CreateMedicalEvent(MedicalEvent medicalEvent);
        Task CreateMedicalEventDetails(IEnumerable<MedicalEventDetail> details);
        Task<MedicalEvent> GetMedicalEventById(string medicalEventId);
        Task UpdateMedicalEvent(MedicalEvent medicalEvent);
        Task AddMedicalEventImage(string medicalEventId, string fileId);
    }

    public class MedicalEventRepository : IMedicalEventRepository
    {
        private readonly DataContext _context;

        public MedicalEventRepository(DataContext context)
        {
            _context = context;
        }

        public async Task<MedicalEvent> CreateMedicalEvent(MedicalEvent medicalEvent)
        {
            _context.MedicalEvent.Add(medicalEvent);
            await _context.SaveChangesAsync();
            return medicalEvent;
        }

        public async Task CreateMedicalEventDetails(IEnumerable<MedicalEventDetail> details)
        {
            _context.MedicalEventDetail.AddRange(details);
            await _context.SaveChangesAsync();
        }

        public async Task<MedicalEvent> GetMedicalEventById(string medicalEventId)
        {
            return await _context.MedicalEvent
                .Include(m => m.MedicalEventDetail)
                .Include(m => m.Image)
                .FirstOrDefaultAsync(m => m.MedicalEventID == medicalEventId);
        }

        public async Task UpdateMedicalEvent(MedicalEvent medicalEvent)
        {
            _context.MedicalEvent.Update(medicalEvent);
            await _context.SaveChangesAsync();
        }
        public async Task AddMedicalEventImage(string medicalEventId, string fileId)
        {
            var medicalEvent = await _context.MedicalEvent.FindAsync(medicalEventId);
            if (medicalEvent == null)
            {
                throw new Exception("Medical event not found");

            }
            var file = await _context.Files.FindAsync(fileId);
            if (file == null)
            {
                throw new Exception("Image file not found");
            }
           // medicalEvent.Image = file;
            await _context.SaveChangesAsync();
        }
    }
}

