﻿namespace Sever.DTO.File
{
    public class ImageUpload
    {
        public IFormFile File { get; set; }
        public string MedicineID { get; set; }
    }
}
