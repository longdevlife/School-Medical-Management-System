﻿using System.ComponentModel.DataAnnotations;

namespace Sever.DTO.MedicalEvent
{
    public class MedicineEventRequest
    {
        [Required]
        public DateTime EventDateTime { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string ActionTaken { get; set; } // Includes supplies and prescriptions used
        public string Notes { get; set; }
        [Required]
        public string EventTypeID { get; set; }
        [Required]
        public string NurseID { get; set; }
        [Required]
        public List<string> StudentID { get; set; }
        public IFormFile Image { get; set; }
    }
}
