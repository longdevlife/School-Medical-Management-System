﻿namespace Sever.DTO.Authentication
{
    public class ForgotPasswordRequest
    {
        public string UsernameOrEmail { get; set; } = "";
    }
}
