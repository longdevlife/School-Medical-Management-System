﻿using Microsoft.EntityFrameworkCore;
using Sever.Context;
using Sever.DTO.File;
using Sever.DTO.SendMedicine;
using Sever.Model;
using Sever.Repository;
using System;

namespace Sever.Service
{
    public interface IMedicineService
    {
        Task<Medicine> CreateMedicineAsync(MedicineDTO medicineDto, string createdBy);
        Task<Medicine> UpdateMedicineAsync(string medicineId, MedicineUpdateDTO updateDto, string modifiedBy);
        Task<Medicine> ChangeStatusAsync(string medicineId, string newStatus, string modifiedBy, string changeDescription);
        Task AddMedicinePhotoAsync(ImageUpload fileDto, string uploadedBy);
        Task<List<MedicineHistory>> GetMedicineHistoryAsync(string medicineId);
    }
    public class MedicineService : IMedicineService
    {
        private readonly IMedicineRepository _medicineRepository;
        private readonly IFilesService _filesService;
        private readonly INotificationService _notificationService;

        public MedicineService(
            IMedicineRepository medicineRepository,
            IFilesService filesService,
            INotificationService notificationService)
        {
            _medicineRepository = medicineRepository;
            _filesService = filesService;
            _notificationService = notificationService;
        }

        public async Task<Medicine> CreateMedicineAsync(MedicineDTO medicineDto, string createdBy)
        {
            try
            {
                var isNurse = createdBy != medicineDto.ParentID;
                var medicine = new Medicine
                {
                    MedicineName = medicineDto.MedicineName,
                    Quantity = medicineDto.Quantity,
                    Dosage = medicineDto.Dosage,
                    Instructions = medicineDto.Instructions,
                    SentDate = medicineDto.SentDate,
                    Notes = medicineDto.Notes ?? (isNurse ? "Tạo bởi y tá – chưa có xác nhận phụ huynh" : null),
                    ParentID = medicineDto.ParentID,
                    Status = isNurse ? "Đã xác nhận" : "Chờ xử lý"
                };

                await _medicineRepository.CreateMedicineAsync(medicine);

                if (!int.TryParse(medicineDto.Quantity, out int doseCount) || doseCount <= 0)
                {
                    throw new ArgumentException("Số lượng liều không hợp lệ");
                }


                var history = new MedicineHistory
                {
                    MedicineID = medicine.MedicineID,
                    ModifiedBy = createdBy,
                    ChangeDescription = "Tạo đơn thuốc",
                    ModifiedAt = DateTime.UtcNow.AddHours(7),
                    PreviousStatus = null,
                    NewStatus = medicine.Status
                };

                await _medicineRepository.AddHistoryAsync(history);

                if (isNurse)
                {
                    await _notificationService.MedicineNotification(medicine, "Đơn thuốc được tạo bởi y tá. Vui lòng kiểm tra và xác nhận.");
                }

                return medicine;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi tạo đơn thuốc.", ex);
            }
        }

        public async Task<Medicine> UpdateMedicineAsync(string medicineId, MedicineUpdateDTO updateDto, string modifiedBy)
        {
            try
            {
                var medicine = await _medicineRepository.GetMedicineByIdAsync(medicineId);
                if (medicine == null)
                {
                    throw new Exception("Không tìm thấy đơn thuốc.");
                }

                var previousStatus = medicine.Status;

                medicine.MedicineName = updateDto.MedicineName;
                medicine.Quantity = updateDto.Quantity;
                medicine.Dosage = updateDto.Dosage;
                medicine.Instructions = updateDto.Instructions;
                medicine.SentDate = updateDto.SentDate;
                medicine.Notes = updateDto.Notes;
                medicine.Status = updateDto.Status;
 

                var history = new MedicineHistory
                {
                    MedicineID = medicineId,
                    ModifiedBy = modifiedBy,
                    ChangeDescription = $"Cập nhật chi tiết đơn thuốc. Trạng thái thay đổi từ {previousStatus} sang {updateDto.Status}",
                    ModifiedAt = DateTime.UtcNow.AddHours(7),
                    PreviousStatus = previousStatus,
                    NewStatus = updateDto.Status
                };
                await _medicineRepository.AddHistoryAsync(history);

                await _medicineRepository.UpdateMedicineAsync(medicine);

                await _notificationService.MedicineNotification(medicine, "Đơn thuốc đã được cập nhật. Vui lòng kiểm tra và xác nhận.");

                return medicine;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi cập nhật đơn thuốc.", ex);
            }
        }

        public async Task<Medicine> ChangeStatusAsync(string medicineId, string newStatus, string modifiedBy, string changeDescription)
        {
            try
            {
                var medicine = await _medicineRepository.GetMedicineByIdAsync(medicineId);
                if (medicine == null)
                {
                    throw new Exception("Không tìm thấy đơn thuốc.");
                }

                var previousStatus = medicine.Status;
                medicine.Status = newStatus;

                var history = new MedicineHistory
                {
                    MedicineID = medicineId,
                    ModifiedBy = modifiedBy,
                    ChangeDescription = changeDescription,
                    ModifiedAt = DateTime.UtcNow.AddHours(7),
                    PreviousStatus = previousStatus,
                    NewStatus = newStatus
                };
                await _medicineRepository.AddHistoryAsync(history);

                await _medicineRepository.UpdateMedicineAsync(medicine);

                await _notificationService.MedicineNotification(medicine, $"Trạng thái đơn thuốc được cập nhật thành {newStatus}. Vui lòng kiểm tra.");

                return medicine;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi thay đổi trạng thái đơn thuốc.", ex);
            }
        }

        public async Task AddMedicinePhotoAsync(ImageUpload fileDto, string uploadedBy)
        {
            try
            {
                var medicine = await _medicineRepository.GetMedicineByIdAsync(fileDto.MedicineID);
                if (medicine == null)
                {
                    throw new Exception("Không tìm thấy đơn thuốc.");
                }

                var imageResponse = await _filesService.UploadImageAsync(fileDto.File);

                var file = new Files
                {
                    FileName = fileDto.File.FileName,
                    FileType = "Image",
                    FileLink = imageResponse.Url,
                    UploadDate = imageResponse.UploadedAt,
                    MedicineID = fileDto.MedicineID
                };

                //await _filesService.UploadImageAsync(file);

                var history = new MedicineHistory
                {
                    MedicineID = fileDto.MedicineID,
                    ModifiedBy = uploadedBy,
                    ChangeDescription = $"Đã tải lên ảnh: {fileDto.File.FileName}",
                    ModifiedAt = DateTime.UtcNow.AddHours(7),
                    PreviousStatus = medicine.Status,
                    NewStatus = medicine.Status
                };
                await _medicineRepository.AddHistoryAsync(history);

                await _notificationService.MedicineNotification(medicine, $"Ảnh mới được tải lên cho đơn thuốc: {fileDto.File.FileName}");

            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi tải lên ảnh đơn thuốc.", ex);
            }
        }

        public async Task<List<MedicineHistory>> GetMedicineHistoryAsync(string medicineId)
        {
            return await _medicineRepository.GetMedicineHistoryAsync(medicineId);
        }
    }
}

