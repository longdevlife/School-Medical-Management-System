﻿using Microsoft.EntityFrameworkCore;
using Sever.Context;
using Sever.DTO.MedicalEvent;
using Sever.Model;
using Sever.Repository;
using Sever.Repository.Interfaces;

namespace Sever.Service
{
    public interface INotificationService
    {
        Task MedicalEventNotification(MedicalEvent medicalEvent, string customMessage = null);
        Task MedicineNotification(Medicine medicine, string customMessage = null);


    }
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _notificationRepository;
        private readonly DataContext _context;

        public NotificationService(
            INotificationRepository notificationRepository,
            DataContext context )
        {
            _notificationRepository = notificationRepository ?? throw new ArgumentNullException(nameof(notificationRepository));
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task MedicalEventNotification(MedicalEvent medicalEvent, string customMessage = null)
        {
            try
            {

                // Get students involved in the medical event
                var studentIds = await _context.MedicalEventDetail
                    .Where(d => d.MedicalEventID == medicalEvent.MedicalEventID)
                    .Select(d => d.StudentID)
                    .ToListAsync();

                if (!studentIds.Any())
                {
                    return;
                }

                // Assume students are linked to parents via User table or a related table
                // Adjust this query based on your actual schema
                var parentIds = await _context.Users
                    .Where(u => u.StudentProfile.Any(sp => studentIds.Contains(sp.StudentID)) && u.RoleID == 1)
                    .Select(u => u.UserID)
                    .ToListAsync();
                if (!parentIds.Any())
                {
                    return;
                }

                // Create notifications for each parent
                foreach (var parentId in parentIds)
                {
                    var notification = new Notify
                    {
                        FormID = "SỰ KIỆN Y TẾ",
                        UserID = parentId,
                        NotifyName = "Cập nhật sự kiện y tế",
                        DateTime = DateTime.UtcNow.AddHours(7),
                        Title = "CẬP NHẬT SỰ KIỆN Y TẾ",
                        Description = customMessage ?? $"Sự kiện y tế mới được ghi nhận vào {medicalEvent.EventDateTime:dd/MM/yyyy HH:mm}. Vui lòng kiểm tra chi tiết."
                    };

                    await _notificationRepository.AddNotificationAsync(notification);
                }

                // TODO: Implement actual notification delivery (e.g., email, push notification)
                // Schedule reminder after 24 hours if no response (requires background job)
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi gửi thông báo sự kiện y tế.", ex);
            }
        }
        public async Task MedicineNotification(Medicine medicine, string customMessage = null)
        {
            try
            {

                if (string.IsNullOrEmpty(medicine.ParentID))
                {
                    return;
                }

                var parentExists = await _context.Users
                    .AnyAsync(u => u.UserID == medicine.ParentID && u.RoleID == 1); // RoleID 1 = Parent

                if (!parentExists)
                {
                    return;
                }
                var notification = new Notify
                {
                    //FormID = "ĐƠN THUỐC",
                    UserID = medicine.ParentID,
                    NotifyName = "Cập nhật thông tin đơn thuốc",
                    DateTime = DateTime.UtcNow.AddHours(7),
                    Title = "CẬP NHẬT ĐƠN THUỐC",
                    Description = customMessage ?? $"Đơn thuốc {medicine.MedicineName} đã được cập nhật. Vui lòng kiểm tra chi tiết."
                };

                await _notificationRepository.AddNotificationAsync(notification);

                // TODO: Implement actual notification delivery (e.g., email, push notification)
                // Schedule reminder after 24 hours if no response (requires background job)
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi gửi thông báo đơn thuốc.", ex);
            }
        }
    }
}
