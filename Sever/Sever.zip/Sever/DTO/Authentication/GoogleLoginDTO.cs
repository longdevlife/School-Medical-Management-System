﻿namespace Sever.DTO.Authentication
{
    public class GoogleLoginDto
    {
        public string IdToken { get; set; }
    }

}
