﻿using Sever.Context;
using Sever.Model;

namespace Sever.Repository.Interfaces
{
    public interface INotificationRepository
    {
        Task AddNotificationAsync(Notify notification);
    }
    public class NotificationRepository : INotificationRepository
    {
        private readonly DataContext _context;

        public NotificationRepository(DataContext context)
        {
            _context = context;
        }

        public async Task AddNotificationAsync(Notify notification)
        {
            await _context.Notify.AddAsync(notification);
            await _context.SaveChangesAsync();
        }
    }
}
